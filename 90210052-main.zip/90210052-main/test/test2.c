bool valid_triagle(float a, float b, float c);

bool valid_triagle(float a, float b, float c)

if (x <= 0 || y <= 0 || z <= 0)
{
    
}